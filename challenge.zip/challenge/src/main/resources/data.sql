-- insert into users_tasks values('Qtask1', 'quser1@gmail')
-- insert into users_tasks values('Qtask1', 'quser2@gmail')

insert into users_tasks values ('dsad', 'murad@gmail.com')